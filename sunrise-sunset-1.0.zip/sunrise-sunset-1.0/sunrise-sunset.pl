#!/usr/bin/perl
use strict;
use warnings;
use POSIX qw(floor acos asin);

# Sunrise-Sunset v1.0  (Perl version)
# Equivalent logic to the FreeBASIC implementation

sub deg2rad { $_[0] * atan2(1,1) / 45.0 }
sub rad2deg { $_[0] * 45.0 / atan2(1,1) }

sub to_julian_day {
    my ($y,$m,$d)=@_;
    if ($m<=2){$y--;$m+=12;}
    my $A=int($y/100);
    my $B=2-$A+int($A/4);
    return int(365.25*($y+4716))+int(30.6001*($m+1))+$d+$B-1524.5;
}

sub parse_coord {
    my $s=uc shift; $s=~s/\s+//g; return 1e37 unless length $s;
    my $sign=1;
    if ($s=~s/[SW]$//){$sign=-1;}
    elsif($s=~s/[NE]$//){$sign=1;}
    return $sign*$s;
}

sub parse_tz {
    my $s=shift; $s=~s/\s+//g; return 1e37 unless length $s; $s=~s/^\+//; return $s;
}

sub pad2 { sprintf "%02d", $_[0] }

sub print_time {
    my ($j,$tz,$label)=@_;
    my $Z=floor($j+0.5);
    my $F=($j+0.5)-$Z;
    my $hours=$F*24+$tz;
    $hours+=24 while $hours<0;
    $hours-=24 while $hours>=24;
    my $hh=int($hours);
    my $mm=int(($hours-$hh)*60+0.5);
    $mm=0,$hh++ if $mm==60;
    $hh-=24 if $hh>=24;
    printf "%s = %02d:%02d\n",$label,$hh,$mm;
}

if (grep {$_ eq '-h'||$_ eq '--help'||$_ eq '-?'} @ARGV){
    print "Usage: sunrise-sunset [lat lon yyyy mm dd tz]\n";
    print "Example: sunrise-sunset 40.7128 -74.0060 2025 6 21 -5\n"; exit;
}

my ($lat,$lon,$y,$m,$d,$tz);

if (@ARGV>=6){
    ($lat,$lon,$y,$m,$d,$tz)=@ARGV;
    $lat=parse_coord($lat); $lon=parse_coord($lon); $tz=parse_tz($tz);
}else{
    print "Enter latitude (e.g. 40.7128N): "; chomp($lat=<STDIN>); $lat=parse_coord($lat);
    print "Enter longitude (e.g. -74.0060 or 151.2093E): "; chomp($lon=<STDIN>); $lon=parse_coord($lon);
    print "Enter timezone offset from UTC (numeric only, e.g. -5 or +1): "; chomp($tz=<STDIN>); $tz=parse_tz($tz);
    print "Enter date (YYYY MM DD): "; chomp(my $line=<STDIN>); ($y,$m,$d)=split(/\s+/,$line);
}

my $h0=-0.833;
my $jd=to_julian_day($y,$m,$d);
my $n=$jd-2451545.0009-$lon/360.0;
my $M=357.5291+0.98560028*$n;
my $C=1.9148*sin(deg2rad($M))+0.0200*sin(deg2rad(2*$M))+0.0003*sin(deg2rad(3*$M));
my $lambda=$M+$C+102.9372+180.0; $lambda-=360.0*int($lambda/360.0);
my $delta=rad2deg(asin(sin(deg2rad($lambda))*sin(deg2rad(23.44))));
my $Jtransit=2451545.0009+$lon/360.0+$n+0.0053*sin(deg2rad($M))-0.0069*sin(deg2rad(2*$lambda));
my $phi=deg2rad($lat); my $dec=deg2rad($delta); my $h=deg2rad($h0);
my $cosH=(sin($h)-sin($phi)*sin($dec))/(cos($phi)*cos($dec));

if (abs($cosH)>1){
    print $cosH>1?"The sun never rises":"The sun never sets"," on this date.\n"; exit;
}

my $H=rad2deg(acos($cosH));
my $Jrise=$Jtransit-$H/360.0;
my $Jset =$Jtransit+$H/360.0;

printf "Results for %d-%02d-%02d at lat %.4f, lon %.4f (TZ %s)\n",$y,$m,$d,$lat,$lon,$tz;
print_time($Jrise,$tz,"Sunrise");
print_time($Jset ,$tz,"Sunset");
